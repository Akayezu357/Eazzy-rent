<!DOCTYPE html>
<html>
<title>W3.CSS</title>

<style>
.content
{
  position:static;
  padding-top: 0px;
  padding-left: 25%;
 width:50%;

}
</style>
<body>


<div class="content">
 
<img class="mySlides" src="a.jpeg" style="width:100%">
<img class="mySlides" src="b.jpeg" style="width:100%">

</div>

<script>
var slideIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > x.length) {slideIndex = 1} 
    x[slideIndex-1].style.display = "block"; 
    setTimeout(carousel, 3000); 
}
</script>

</body>
</html>
