<?php
  $server="localhost";
  $user="root";
  $password="";
  $db="personal_info1";
  $co=mysqli_connect($server,$user,$password,$db);
  if ($co) {
      //echo"connected";
  } else {
      echo"not connected";
  }
?>