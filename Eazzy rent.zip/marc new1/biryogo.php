<html>
<head>

<title>biryogo</title>
<style type="text/css">
    .nav{
    width: 1100px;
    height: 60px;
    margin: 0 auto;
    border-radius: 10px;
}
ul li {
    list-style: none;
    width: 200px;
    line-height: 60px;
    position: relative;
    background: #222;
    box-shadow: 0px 2px 5px 0px grey;
    text-align: center;
    float: left;
    background-color: skyblue;

}
ul li ul{
    position: absolute;
}
.nav > ul > li:nth-of-type(1){
    border-radius: 5px 0px 0px 5px;
}
.nav > ul > li:nth-of-type(5){
    border-radius: 0px 5px 5px 0px;
}
.nav > ul > li:nth-of-type(1){
    border-radius: 5px 0px 0px 5px;
}   
.nav > ul >li:nth-of-type(5){
    border-radius: 0px 5px 5px 0px;
}
ul li a{
    color: green;
    width: 155px;
    height: 58px;
    display: inline-block;
    text-decoration: none;
}
ul li a:hover{
    font-weight: bold;
    border-bottom: 8px solid #fff;
}
ul li ul{
    display: none;
    padding-left: 0px;

}
.nav ul li:hover ul{
    display: block;
}
.fa{
    margin-right: 5px;
}
.container{
    width: 300px;
    height: 50px;
    margin: 0 auto;
    padding:20px 20px;
}
@media screen and (max-width: 480px){
    header{
        width: 100%;
    }
    .nav{
        align-content: left;
        display: none;
        width: 100%;
        height: auto;
    }
    ul li{
        width: 100%;
        float: none;
    }
    ul li a{
        width: 100%;
        display: block;
    }
    ul li ul{
        position: static;

    }
    ul li ul li a{
        background: #222;
        text-align: left;
    }
    .fa.list.modify{
        display: block;
    }
    .container{
        width: 100%;
        height: 100%;
    }
    table{
        width: 100% 

    }
</style>
</head>
<img src="images.png" height="10%"><br>Eazzyrent
<nav class="nav">
<ul>
   <li><a href="photos.html"> welcome </a></li>
    <li><a href="pricedraft1.html">prices</a>
      <ul>
        <li><a href="pricedraft2.html">for noble class</a></li>
        <li><a href="pricedraft3.html">for lower class</a></li>
        

      </ul>
    </li>
    <li><a href="services.html">Services</a></li>
    <li><a href="contacts.html">Contact us</a></li>
    <li><a href="login2.html">Login</a>
     <ul>
        <li><a href="login2.html">having reg number</a></li>
        <li><a href="Login.html">new student</a></li>
        <li><a href="Loginadmin.php">admin</a></li>
     </ul>
    </li>
    
</ul>
</nav>
<a href="login.html"><h1><b><P ALIGN="right">CLICK HERE TO LOGIN</p></h1></a>

<marquee direction="right" height="10%" width="100%" bgcolor="#FFFAF0"><h1 style="color: green">please login first</h1></marquee>

 <marquee direction="left" height="80%" width="100%" bgcolor="#FFFAF0"><h1 style="color: green"><img src="h10.jfif" width="100%" height="100%"></h1></marquee>

<a href="homepage.html"><h1><b style="color:indigo">BACK</h1></b></a>
<br>
<table>
	<tr id="e"><td>Name:Akayezu Marc <span style="text-align:center;">email:marcakayezu97@gmail.com </span><span text-aling=left;> Address:Nyarugenge</span></td></tr>
<tr id="a"><td><a href="http://www.whatsapp.com"><img src="wtp.png" height="50%"></a><span style="text-align:center;"><a href="http://www.facebook-marcakanyagasani.com"><img src="fb2.jfif"  height="50%"></a></span><a href="http://www.instagram.com"><img src="inst.jfif"  height="50%"> </a><span text-aling=left;><a href="http://www.facebook.com"><img src="twt.jfif" height="50%"></a></span></td></tr>
<tr id="a"><td><h1>+250780987654       Akanyagasani    <i>@marcakanyagasani</i></h1></td></tr>
</table>


</html>
