<html>
<head>
<title>eazzyrent</title>

<style type="text/css">
.nav{
    width: 1100px;
    height: 60px;
    margin: 0 auto;
    border-radius: 10px;
}
ul li {
    list-style: none;
    width: 200px;
    line-height: 60px;
    position: relative;
    background: #222;
    box-shadow: 0px 2px 5px 0px grey;
    text-align: center;
    float: left;
    background-color: skyblue;

}
ul li ul{
    position: absolute;
}
.nav > ul > li:nth-of-type(1){
    border-radius: 5px 0px 0px 5px;
}
.nav > ul > li:nth-of-type(5){
    border-radius: 0px 5px 5px 0px;
}
.nav > ul > li:nth-of-type(1){
    border-radius: 5px 0px 0px 5px;
}   
.nav > ul >li:nth-of-type(5){
    border-radius: 0px 5px 5px 0px;
}
ul li a{
    color: green;
    width: 155px;
    height: 58px;
    display: inline-block;
    text-decoration: none;
}
ul li a:hover{
    font-weight: bold;
    border-bottom: 8px solid #fff;
}
ul li ul{
    display: none;
    padding-left: 0px;

}
.nav ul li:hover ul{
    display: block;
}
.fa{
    margin-right: 5px;
}
.container{
    width: 300px;
    height: 50px;
    margin: 0 auto;
    padding:20px 20px;
}
@media screen and (max-width: 480px){
    header{
        width: 100%;
    }
    .nav{
        align-content: left;
        display: none;
        width: 100%;
        height: auto;
    }
    ul li{
        width: 100%;
        float: none;
    }
    ul li a{
        width: 100%;
        display: block;
    }
    ul li ul{
        position: static;

    }
    ul li ul li a{
        background: #222;
        text-align: left;
    }
    .fa.list.modify{
        display: block;
    }
    .container{
        width: 100%;
        height: 100%;
    }
   
    a{
        text-decoration: none;
        color: white;
    }
    span {
        padding: 60px;
    }
    #a{
        background-color: gray;
        height: 40px;
        
    }
    

</style>
<script type="text/javascript">

function myform(){
var x=prompt("type your reg number"," ");
if(x.length<9){
alert("imcomplete reg number");
return myform();
}

else if(x.length>9){
alert("reg number is too long");
return myform();
}

else{
alert("welcome to eazzyrent");
}
}
function validate_email(field,alerttxt)
 { 
 	with (field) 
 	  { 
 	    apos=value.indexOf("@"); 
 	      dotpos=value.lastIndexOf(".");
 	         if (apos<1||dotpos-apos<2)
 	             {
 	              	alert(alerttxt);
 	              	return false;
 	              }
 	                 else {
 	                 	return true;
 	                      }
 	              }
 	            } 
 
function validate_form(thisform)
 {
  with (thisform)
     { 
  
 

  if (validate_email(email,"Not a valid e-mail address!")==false) 
      {
      email.focus();
  return false;
      } 
        } 
    } 

</script>
</head>
<img src="images.png" height="10%"><br>Eazzyrent
<nav class="nav">
<ul>
   <li><a href="homepagee.html"> Home</a></li>
    <li><a href="pricedraft1.html">prices</a>
      <ul>
        <li><a href="pricedraft2.html">for noble class</a></li>
        <li><a href="pricedraft3.html">for lower class</a></li>
        

      </ul>
    </li>
    <li><a href="services.html">Services</a></li>
    <li><a href="contacts.html">Contact us</a></li>
    <li><a href="login2.html">Login</a>
     <ul>
        <li><a href="login2.html">having reg number</a></li>
        <li><a href="Login.html">new student</a></li>
        <li><a href="Loginad.php">admin</a></li>
     </ul>
    </li>
    
</ul>
</nav>
<body onload="myform()" bgcolor="white">
		<script>

document.write(y);
if (y.size()<8) {
	alert("reg number is too short");
} else if(y.size()>8){
	alert("reg number is too long");
	
}
else{
	alert("welcome to eazzyrent");
}
</script
<p class="dashed"> 
<u><h1><b>WELCOME TO EAZZYRENT</h1></u></b>
</hr>
please enter your address so that we can help you<br>
<form onsubmit="myform">
reg number:<br>
<input type="text" name="reg number" />
<br/>
telephone:
<input type="text" contact="telephone" />
<br/>
email addresses:
<form action="submit.html" onsubmit="return validate_form(this);" method="post"> Email: <input type="Email" name="email" size="30">  
<br/>


<br/>
<form>
I have a bike:
<input type="checkbox" name="vehicle" value="Bike" />
<br />
I have a car:
<input type="checkbox" name="vehicle" value="Car" />
<br />
I have wife/husband and children:
<input type="checkbox" name="family" value="I have wife/husband and children" />
<br/>
none of above:
<input type="checkbox" name="none" value="none of above"/>
<br/>
 <br/>
<form name="input" action="html_form_submit.asp" method="get">
i comfirm that informations provided are true:
</br>
<input type="submit" value="save"/>
<br>

</form>
</form>
</form>
</form>
</form>
</p> 
</body>

</html>