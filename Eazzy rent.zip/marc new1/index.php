
<form method="post"> 
   Fname: <input type="text" size="50" name="fname"> <br/><br/>
   Password: <input type="password" size="50" name="lname"> <br/><br/>
    <input type="submit"  name="submit" value="SEND">
	<input type="submit"  name="retrieve" value="RETRIEVE">
</form>
<?php
  include("connection.php");
  
  if(isset($_POST["submit"])){
      $name = $_POST["fname"];
      $password = md5($_POST["lname"]);
      //////////////////
      $query = "INSERT INTO user(id, fname, password)
	        VALUES('','$name','$password')";
      
	  $result = mysqli_query($conn,$query);
	  if($result){
		  echo "Successfully Inserted";
	  }else{
		  echo "Something is wrong!";
	  }
      //////////////////////	  
      //echo $name." Password ".$password;
  }else{
	  $query = "SELECT * FROM user";
      
	  $result = mysqli_query($conn,$query);
	  while($row =mysqli_fetch_array($result)){
		    echo $row['id']." ".$row['fname']." ".$row['password']." "."<img src='im2.jpg' height='30' width='30'>"."<br/>";
		    //echo "Successfully Inserted";
	  }
	  //echo "You clicked RETRIEVE Botton";
  }
?>