
<html>
<head>
<title>eazzyrent</title>
v 
<style type="text/css">
.nav{
    width: 1100px;
    height: 60px;
    margin: 0 auto;
    border-radius: 10px;
}
ul li {
    list-style: none;
    width: 200px;
    line-height: 60px;
    position: relative;
    background: #222;
    box-shadow: 0px 2px 5px 0px grey;
    text-align: center;
    float: left;
    background-color: skyblue;

}
ul li ul{
    position: absolute;
}
.nav > ul > li:nth-of-type(1){
    border-radius: 5px 0px 0px 5px;
}
.nav > ul > li:nth-of-type(5){
    border-radius: 0px 5px 5px 0px;
}
.nav > ul > li:nth-of-type(1){
    border-radius: 5px 0px 0px 5px;
}   
.nav > ul >li:nth-of-type(5){
    border-radius: 0px 5px 5px 0px;
}
ul li a{
    color: green;
    width: 155px;
    height: 58px;
    display: inline-block;
    text-decoration: none;
}
ul li a:hover{
    font-weight: bold;
    border-bottom: 8px solid #fff;
}
ul li ul{
    display: none;
    padding-left: 0px;

}
.nav ul li:hover ul{
    display: block;
}
.fa{
    margin-right: 5px;
}
.container{
    width: 300px;
    height: 50px;
    margin: 0 auto;
    padding:20px 20px;
}
@media screen and (max-width: 480px){
    header{
        width: 100%;
    }
    .nav{
        align-content: left;
        display: none;
        width: 100%;
        height: auto;
    }
    ul li{
        width: 100%;
        float: none;
    }
    ul li a{
        width: 100%;
        display: block;
    }
    ul li ul{
        position: static;

    }
    ul li ul li a{
        background: #222;
        text-align: left;
    }
    .fa.list.modify{
        display: block;
    }
    .container{
        width: 100%;
        height: 100%;
    }
    table{
        width: 100% 

    }
    a{
        text-decoration: none;
        color: white;
    }
    span {
        padding: 60px;
    }
   
</style>

</head>
<img src="images.png" height="10%"><br>Eazzyrent
<nav class="nav">
<ul>
   <li><a href="homepagee.php"> Home </a></li>
    <li><a href="pricedraft1.php">prices</a>
      <ul>
        <li><a href="pricedraft2.php">for noble class</a></li>
        <li><a href="pricedraft3.php">for lower class</a></li>
        

      </ul>
    </li>
    <li><a href="services.php">Services</a></li>
    <li><a href="contacts.php">Contact us</a></li>
    <li><a href="login2.php">Login</a>
     <ul>
        <li><a href="login2.php">having reg number</a></li>
        <li><a href="Login.php">new student</a></li>
        <li><a href="Loginadmin.php">admin</a></li>
     </ul>
    </li>
    
</ul>
</nav>
<body onsubmit="wel()" bgcolor="white">
 
<u><h1><b>WELCOME TO EAZZYRENT</h1></u></b>
</hr>
<form method="POST" >
username: <input type="name" name="username"><br>
password: <input type="password" name="password"><br>
id: <input type="text" name="admin_id">
<br>
<input type="submit"  name="submit" value="SEND" >
<input type="submit"  name=""RETRIEVE" value="RETRIEVE" >


</form>

</body>

</html>

<?php


$server="localhost";
  $user="root";
  $password="";
  $db="personal_info1";
  $co=mysqli_connect($server,$user,$password,$db);
$name;
$password;
$id;
if (isset($_POST["submit"])) {
    $name=$_POST["username"];
    $password=md5($_POST["password"]);
    $id=$_POST["admin_id"];
    //ALTER table admin add column a_photo(p_name varchar(50),)
    $query = "INSERT INTO admin(username, password, admin_id)
	        VALUES('$name','$password',' $id')";
      
	  $result = mysqli_query($co,$query);
	  if($result){
          echo "Successfully Inserted";
          echo"now you are admin";
          
	  }else{
         // echo "Something is wrong!";
         include("prices.php");
         
	  }

   // echo $name." "."password".":".$password;
} else {
    $query = "SELECT * FROM admin";
      
	  $result = mysqli_query($co,$query);
	  while($row =mysqli_fetch_array($result)){
		    echo $row['admin_id']." ".$row['username']." ".$row['password']." "."<br/>";
		    //echo "Successfully Inserted";
	  }
    //echo "you clicked retrieve" ;
}

include("connection.php");

?>
