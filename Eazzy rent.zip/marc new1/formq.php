<?php


$server="localhost";
  $user="root";
  $password="";
  $db="personal_info";
  $co=mysqli_connect($server,$user,$password,$db);
$fname;
$lname;
$tel;
$email;
if (isset($_POST["submit"])) {
    $fname=$_POST["fname"];
    $lname=$_POST["lname"];
    $tel=$_POST["telephone"];
    $email=$_POST["email"];
    //ALTER table admin add column a_photo(p_name varchar(50),)
    $query = "INSERT INTO guest(fname, lname, telephone,email)
	        VALUES('$fname','$lname',' $tel','$email')";
      
	  $result = mysqli_query($co,$query);
	  if($result){
		  echo "Successfully Inserted";
	  }else{
		  echo "Something is wrong!";
	  }

   // echo $name." "."password".":".$password;
} else {
    $query = "SELECT * FROM guest";
      
	  $result = mysqli_query($co,$query);
	  while($row =mysqli_fetch_array($result)){
		    echo $row['fname']." ".$row['lname']." ".$row['telephone'].$row['email']." "."<br/>";
		    //echo "Successfully Inserted";
	  }
    //echo "you clicked retrieve" ;
}

include("connection.php");

?>